#!/bin/bash
name=$(zenity --color-selection --show-palette --title Color\ Select)
copyq add $name
